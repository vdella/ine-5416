module Main where

import Formas

main = do
    let trapezio = Trapezio 1 2 3
    print (area trapezio)
